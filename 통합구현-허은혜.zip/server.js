// express
const express = require("express");
const app = express();

app.use(express.static(__dirname + '/visitor'));

// body-parser
app.use(express.urlencoded({extended:true}));

// mongodb
const MongoClient = require('mongodb').MongoClient;

// 데이터베이스 접근
let dbUrl = 'mongodb+srv://admin:qwer1234@cluster0.3uwxb.mongodb.net/visitorDB?retryWrites=true&w=majority';
let visitorApp;

MongoClient.connect(dbUrl,
    (error,client)=>{ 
        if(error) return console.log('데이터베이스 오류');
        
        visitorApp = client.db('bookDB');

        app.listen(8080,()=>{
            console.log('8080 포트 오픈');
        })
    }
)

app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/visitor/index.html')
})

app.post('/add',(req,res)=>{
    let appTitle = req.body.title;
    let appContent = req.body.content;

    visitorApp.collection('postcount').findOne({제목:'제목',내용:'내용'},(error,result)=>{
        if(error) return console.log('검색 오류');
        let totalCount = result.전체갯수;

        visitorApp.collection('visitorlist').insertOne({title:appTitle, content:appContent},(error,result)=>{
            if(error) return console.log('등록 오류');
            console.log('등록 성공');

            visitorApp.collection('postcount').updateOne({제목:'제목',내용:'내용'},{$inc:{전체갯수:1}},(error,result)=>{
                if(error) return console.log('업데이트 오류');
                res.redirect('/');
            })
        })
    })
})

app.get('/',(req,res)=>{
    visitorApp.collection('visitorlist').find().toArray((error,result)=>{
        if(error) return console.log('자료검색 오류');
        res.render('/visitor/index.html',{visitorData:result})
    })
})
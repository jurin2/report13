
import { Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function Header(props){
    return (
      <header className="black-header" style={ {backgroundColor:"#0069D9"} }>
        <h1>방명록</h1>
        <button onClick={props.onWriteOpen}>글작성</button>
      </header>
    );
  }

  function Section(props){
  
    let listItem = [];
    for(let idx=0; idx<props.listContent.length; idx++){
      listItem.push(
        <Card className="list-item" key={idx} style={ {border:'none'} }>
          <Card.Header as="h5" id={idx} style={ {cursor:'pointer', backgroundColor:'#ccc'} } onClick={(event)=>{props.onModalOpen(); props.onSetID(event.target.id);}}
          > {props.listTit[idx]} </Card.Header>
          <Card.Body style={ {backgroundColor:'#f5f5f5'} }>
            <Card.Text> {props.listContent[idx]} </Card.Text>
          </Card.Body>
        </Card>
      );
    }
  
  
    return (
      <section className="list">
        {listItem}      
      </section>
    );
  }

  export {Header,Section};
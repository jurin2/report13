import './App.css';
import {useState} from 'react';
import {Header,Section} from './Header'

function Modal(props){
  return (
    <section id="modal" className="modal">
      <div className="modal-container">
        <div className="modal-header">
          <button onClick={props.onModalClose}>닫기</button>
        </div>
        <div className="modal-body">
          <div>{props.listTit}</div>
          <div>{props.listContent}</div>
        </div>        
      </div>
    </section>
  );
}
function Write(props){
  return (
    <section id="write" className="write">
      <div className="write-container">
        <div className="write-header">
          <button onClick={()=>{props.onWriteClose();props.onWriteClear();}}>취소</button>
        </div>
          <form className="write-body" action="/add" method="post">
            <input name="title" type="text" onChange={(e)=>{props.setWriteTit(e.target.value)}} placeholder="제목"/>                
            <input name="content" type="text" onChange={(e)=>{props.setWriteContent(e.target.value)}} placeholder="내용"/>      
            <button type='submit' onClick={()=>{props.onListPush();props.onWriteClose(); props.onWriteClear()}}>저장</button>
          </form>
      </div>
    </section>
  );
}


function App() {
  let [writeTit,writeTitChange] = useState('');
  let [writeContent,writeContentChange] = useState('');
  let [viewIdx,viewIdxChange]=useState(0); 
  let [listTit,listTitChange] = useState(['안녕하세요','잘부탁드립니다','처음 방문해요!']);
  let [listContent,listContentChange] = useState([
                                '글 남겨요!',
                                '안녕하세요 글남깁니다',
                                '안녕하세요 글남깁니다2'
                              ]);
  let [best,bestChange] = useState([0,0,0]);
  let newBest = [...best];    
  function bestValue(idx,para){
    if(para==1){
      ++newBest[idx];
      bestChange(newBest);
    }else if(para==2 && newBest[idx] > 0){
      --newBest[idx];
      bestChange(newBest);
    }
  }
  let [modal,modalChange]=useState(false);
  let [write,writeChange]=useState(false);
  function listPush(){
      // 조건
      // 참
      if(writeTit != '' && writeContent != ''){
        let newListTit = [...listTit];
        newListTit.unshift(writeTit);
        listTitChange(newListTit);
        let newListcontent = [...listContent];
        newListcontent.unshift(writeContent);
        listContentChange(newListcontent);
      }
      // 거짓
      // 아무것 안함
  }
  function writeClear(){
    writeTitChange('');
    writeContentChange('');
  }
  return (
    <div className="App">
      <Header onWriteOpen={()=>{writeChange(true)}}/>
      <Section listTit={listTit} listContent={listContent} best={best} onMouseClick={(value1,value2)=>{bestValue(value1,value2)}} onModalOpen={()=>{modalChange(true)}} 
                onSetID={(_id)=>{viewIdxChange(_id)}}/>
      
      {/* 모달창 */}
      {
        modal == true
        ? <Modal listTit={listTit[viewIdx]} listContent={listContent[viewIdx]} onModalClose={()=>{modalChange(false)}}/>
        : null
      }    

      {/* 기록창 */}
      {
        write == true
        ? <Write 
                onWriteClose={()=>{writeChange(false)}} 
                setWriteTit = {(inputValue)=>{writeTitChange(inputValue)}}
                setWriteContent = {(inputValue)=>{writeContentChange(inputValue)}}
                onListPush={listPush}
                onWriteClear={writeClear}
                // 프롭스전달 writeClear
          />
        : null
      }   
    </div>
  );
}

export default App;
